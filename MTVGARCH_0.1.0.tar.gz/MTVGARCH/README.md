# mtvgjr
M.TV.GJR-GARCH: R-Code for Uni- &amp; Multi-variate modelling of GARCH processes with a Time-Varying (TV) component.  
